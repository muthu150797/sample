import { SpacingOptions } from '@mui/system/createTheme/createSpacing';

const spacing: SpacingOptions = 4;

export default spacing;
