import { ShapeOptions } from '@mui/system/createTheme/shape';

const shape: ShapeOptions = {
  borderRadius: 4,
};

export default shape;
